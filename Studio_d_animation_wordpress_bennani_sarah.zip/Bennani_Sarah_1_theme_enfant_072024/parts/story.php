<section id="story" class="story">
            <h2 class="animate-title">L'histoire</h2>
            <article id="" class="story__article">
                <div>
                <p><?php echo get_theme_mod('story'); ?></p>
                </div>
            </article>
            <?php get_template_part('parts/story-characters'); ?>
            <?php get_template_part('parts/lieu'); ?>

            </article>
        </section>
