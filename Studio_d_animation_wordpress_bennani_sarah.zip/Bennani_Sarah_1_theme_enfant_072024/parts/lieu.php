<article id="place">
                <div class="image-container">                
                    <h3 class="animate-title">Le Lieu</h3>
                    <p><?php echo get_theme_mod('place'); ?></p>
                </div>
                    <img class="littleCloud" src="<?php echo get_theme_file_uri() . '/assets/images/little_cloud.png'; ?>" alt="petitNuage"> 
                    <img class="bigCloud" src="<?php echo get_theme_file_uri() . '/assets/images/big_cloud.png'; ?>" alt="grandNuage">
</article>