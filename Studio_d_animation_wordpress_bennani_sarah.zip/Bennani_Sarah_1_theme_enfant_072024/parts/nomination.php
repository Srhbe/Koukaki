<section class="nomination">
    <h3 class="titreoscars">Fleurs d’oranger & chats errants<br>est nominé aux Oscars Short<br>Film Animated de 2022 !</h3>
        <img src=<?php echo get_theme_file_uri("./assets/images/oscars.png");?> alt="image oscar">
    </section>