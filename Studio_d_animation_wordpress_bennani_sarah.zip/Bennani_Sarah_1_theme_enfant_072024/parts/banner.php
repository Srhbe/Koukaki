<div class="titre">
    <div class="banner"></div>
    <img class="banner__background" src="<?php echo get_theme_file_uri('/assets/images/banner.png'); ?>" alt="">    <video class="banner__video" width="1440" autoplay muted loop poster="<?php echo get_theme_file_uri() . '/assets/images/banner.png'; ?>">                    
        <source src="<?php echo get_theme_file_uri() . '/assets/video/StudioKoukakiVideo.mp4'; ?>" type="video/mp4">
    </video>
    <img src="<?php echo get_template_directory_uri() . '/assets/images/logo.png'; ?>" alt="logo Fleurs d'oranger & chats errants" class="slide-up">
</div>
